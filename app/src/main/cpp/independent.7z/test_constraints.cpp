#include <iostream>
#include <vector>
#include <tuple>

#include "equality_constraint.h"
#include "inequality_constraint.h"
#include "fused_contraint.h"

#include "collocation_constraints.h"
#include "control_rate_constraints.h"
#include "dynamics_constraints.h"
#include "initial_state_constraints.h"
#include "smooth_control_constraints.h"
#include "waypoint_constraint.h"
#include "waypoint_constraints.h"

using std::cout;
using std::endl;

int main() {

    /* Types */
    using Scalar = double;
    using Index = size_t;

    /* Sizes */
    const Index n_x = 6;
    const Index n_u = 4;
    const Index n_c = 4;
    const Index n_w = 11;

    using Get = VariableGetter<Scalar, Index, n_x, n_u, n_c, n_w>;

    /* Control rate bounds */
    Eigen::Matrix<Scalar, n_u, 1> control_rate_upper = Eigen::Matrix<Scalar, n_u, 1>::Random();
    Eigen::Matrix<Scalar, n_u, 1> control_rate_lower = -control_rate_upper;

    /* Initial State */
    Eigen::Matrix<Scalar, n_x, 1> initial_state = Eigen::Matrix<Scalar, n_x, 1>::Random();

    /* Waypoints */
    Eigen::Matrix<Scalar, n_x, n_w> waypoints = Eigen::Matrix<Scalar, n_x, n_w>::Random();

    /* Define the constraints */
    auto constraints = std::make_tuple(
            CollocationConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(),
            ControlRateConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(control_rate_lower, control_rate_upper),
            DynamicsConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(),
            InitialStateConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(initial_state),
            SmoothControlConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(),
            WaypointConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(waypoints)
    );

    /* Create the fused constraint */
    FusedConstraint<decltype(constraints), Scalar, Index, n_x, n_u, n_c, n_w> fused_constraint(constraints);
    const Index N = fused_constraint.n_constraints;

    cout << "Number of Constraints : " << N << endl;

    cout << "Lower bound: ";
    for (Index i = 0; i < N; ++i)
        cout << fused_constraint.lower_bound[i] << ", ";
    cout << endl;

    cout << "Upper bound: ";
    for (Index i = 0; i < N; ++i)
        cout << fused_constraint.upper_bound[i] << ", ";
    cout << endl;

    cout << "Evaluate: ";
    std::vector<Scalar> g(N);
    std::vector<Scalar> X(Get::n_vars);
    for (Index i = 0; i < X.size(); ++i)
        X[i] = i;
    const std::vector<Scalar> x = X;
    for (Index i = 0; i < x.size(); ++i)
        cout << x[i] << ", ";
    cout << endl;

    fused_constraint(g, x);
    for (Index i = 0; i < N; ++i)
        cout << g[i] << ", ";
    cout << endl;

    return 0;
}