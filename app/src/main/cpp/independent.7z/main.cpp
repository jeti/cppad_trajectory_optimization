/* Properly define cout and endl for your system */
#include "cout.h"

/* IPOPT */
#include "IpStdCInterface.h"

/* STL libraries that we are using */
#include <vector>
#include <assert.h>
#include <chrono>
#include <tuple>

/* Our classes */
#include "equality_constraint.h"
#include "inequality_constraint.h"
#include "fused_contraint.h"
#include "variable_getter.h"

#include "collocation_constraints.h"
#include "control_rate_constraints.h"
#include "dynamics_constraints.h"
#include "initial_state_constraints.h"
#include "smooth_control_constraints.h"
#include "waypoint_constraint.h"
#include "waypoint_constraints.h"

/* Eigen */
#include "Eigen/Dense"

/* All of the aliases we use a lot */
using std::endl;

using Eigen::Dynamic;
using Eigen::IOFormat;
using Eigen::Map;
using Eigen::Matrix;

template<typename Scalar, typename Index, Index n_x, Index n_u, Index n_c, Index n_w>
void log_state(Scalar *vars, bool waypoints = true,
               const IOFormat &format = IOFormat(4, 0, " ", "\n", "", "", "", "")) {

    using Get = VariableGetter<Scalar, Index, n_x, n_u, n_c, n_w>;

    /* First, write the times to the string  */
    cout << endl
         << endl;
    cout << "Times: ";
    auto t = Get::times(vars);
    cout << t.format(format);
    cout << endl;

    cout << "----------------------------";
    cout << endl
         << endl;
    cout << "Controls: ";
    cout << endl
         << endl;
    if (waypoints) {
        for (Index i_w = 0; i_w < n_w; ++i_w) {
            cout << "Waypoint " << i_w << endl;
            auto u = Get::controlsAtWaypoint(vars, i_w);
            cout << u.format(format);
            cout << endl
                 << endl;
        }
    } else {
        for (Index i_c = 0; i_c < n_c; ++i_c) {
            cout << "Collocation point " << i_c << endl;
            auto u = Get::controlsAtCollocationPoint(vars, i_c);
            cout << u.format(format);
            cout << endl
                 << endl;
        }
    }
    cout << endl;
    cout << "----------------------------";
    cout << endl
         << endl;
    cout << "States: ";
    cout << endl
         << endl;
    if (waypoints) {
        for (Index i_w = 0; i_w < n_w; ++i_w) {
            cout << "Waypoint " << i_w << endl;
            auto x = Get::statesAtWaypoint(vars, i_w);
            cout << x.format(format);
            cout << endl
                 << endl;
        }
    } else {
        for (Index i_c = 0; i_c < n_c; ++i_c) {
            cout << "Collocation point " << i_c << endl;
            auto x = Get::statesAtCollocationPoint(vars, i_c);
            cout << x.format(format);
            cout << endl
                 << endl;
        }
    }
    cout << endl;
    cout << "----------------------------";
    cout << endl;
}

/* The "main" function that will be called from Java */
#ifdef __ANDROID__

extern "C" JNIEXPORT jdouble JNICALL
Java_io_pcess_trajectory_1optimization_MainActivity_optimizetrajectory(JNIEnv *env,
                                                                       jobject object) {

#else

    int main()
    {

#endif

    /* Types */
    using Scalar = double;
    using Index = size_t;

    /* Sizes */
    const Index n_x = 6;
    const Index n_u = 4;
    const Index n_c = 11;
    const Index n_w = 6;

    using Get = VariableGetter<Scalar, Index, n_x, n_u, n_c, n_w>;
    const Index n_vars = Get::n_vars;

    /*
     * ----------------------------------------------
     *
     * Initial State
     * TODO: Pass from Java
     *
     * ----------------------------------------------
     */
    Matrix<Scalar, n_x, 1> initial_state;
    initial_state.setZero();

    /*
     * ----------------------------------------------
     *
     * Waypoints
     * TODO: Pass from Java
     *
     * ----------------------------------------------
     */
    Matrix<Scalar, n_x, n_w> waypoints;
    waypoints.setZero();
    waypoints.col(0) << 2.0, 2.0, -1.0, 0.0, 0.0, 0.0;
    if (n_w >= 2)
        waypoints.col(1) << 4.0, 2.0, -1.0, 0.0, 0.0, 0.0;
    if (n_w >= 3)
        waypoints.col(2) << 8.0, 0.0, -1.0, 0.0, 0.0, 0.0;
    if (n_w >= 4)
        waypoints.col(3) << 4.0, -2.0, -1.0, 0.0, 0.0, 0.0;
    if (n_w >= 5)
        waypoints.col(4) << 2.0, -2.0, -1.0, 0.0, 0.0, 0.0;
    if (n_w >= 6)
        waypoints.col(5) << 0.0, 0.0, 0.0, 0.0, 0.0, 0.0;

    /*
     * ----------------------------------------------
     *
     * Control Rate Bounds
     *
     * ----------------------------------------------
     */
    const Scalar degrees = M_PI / 180;
    const Scalar max_angular_rate = 30 * degrees;

    Eigen::Matrix<Scalar, n_u, 1> control_rate_upper;
    control_rate_upper << 20, max_angular_rate, max_angular_rate, max_angular_rate;

    Eigen::Matrix<Scalar, n_u, 1> control_rate_lower = -control_rate_upper;

    /*
     * ----------------------------------------------
     *
     * Collocation points
     *
     * ----------------------------------------------
     */
    Matrix<Scalar, n_c, 1> collocation_points = generateCollocationPoints<Scalar, Index, n_c>();

    /*
     * ----------------------------------------------
     *
     * Upper and lower bounds for the variables
     *
     * ----------------------------------------------
     */
    Matrix<Scalar, n_vars, 1> lower_bound;
    Matrix<Scalar, n_vars, 1> upper_bound;

    /* State bounds. We will set the same state bounds for each collocation point and waypoint.  */
    Matrix<Scalar, n_x, 1> x_min;
    x_min << -2e19, -2e19, -2e19, -2e19, -2e19, -2e19;

    Matrix<Scalar, n_x, 1> x_max;
    x_max << 2e19, 2e19, 0, 2e19, 2e19, 2e19;

    for (Index i_w = 0; i_w < n_w; ++i_w) {
        auto x_lower = Get::statesAtWaypoint(lower_bound.data(), i_w);
        x_lower = x_min.replicate<1, n_c>();
        auto x_upper = Get::statesAtWaypoint(upper_bound.data(), i_w);
        x_upper = x_max.replicate<1, n_c>();
    }

    /* Control bounds */
    Matrix<Scalar, n_u, 1> u_min;
    u_min << 0, -30 * degrees, -30 * degrees, -2 * 360 * degrees;

    Matrix<Scalar, n_u, 1> u_max;
    u_max << 2 * 9.91, 30 * degrees, 30 * degrees, 2 * 360 * degrees;

    for (Index i_w = 0; i_w < n_w; ++i_w) {
        auto u_lower = Get::controlsAtWaypoint(lower_bound.data(), i_w);
        u_lower = u_min.template replicate<1, n_c>();
        auto u_upper = Get::controlsAtWaypoint(upper_bound.data(), i_w);
        u_upper = u_max.template replicate<1, n_c>();
    }

    /* Time bounds */
    const Scalar time_min = 0;
    const Scalar time_max = 10;
    Get::times(lower_bound.data()).fill(time_min);
    Get::times(upper_bound.data()).fill(time_max);

    /*
     * ----------------------------------------------
     *
     * Initial guess
     *
     * ----------------------------------------------
     */
    Matrix<Scalar, n_vars, 1> initial_guess;
    initial_guess.setZero();

    /* Set the times to the specified value. */
    Scalar time = 1;
    Get::times(initial_guess.data()).fill(time);

    /* Now compute the difference between each of the waypoints.
     * The first column is the first waypoint - the initial state.
     * The rest are waypoint i - waypoint (i-1)*/
    Matrix<Scalar, n_x, n_w> differences;
    differences << waypoints.col(0) - initial_state,
        waypoints.template rightCols<n_w - 1>() - waypoints.template leftCols<n_w - 1>();

    /* Now we can interpolate the values for the state using the formula
     *
     * interpolated = final - (1 - collocation_point) * ( final - initial )
     */
    Matrix<Scalar, n_c, 1> dc = -collocation_points.array() + 1;
    for (Index i_c = 0; i_c < n_c; ++i_c) {
        auto x = Get::statesAtCollocationPoint(initial_guess.data(), i_c);
        x = waypoints - dc(i_c) * differences;
    }

    /* Note that we are leaving the initial control guesses as zeros. */

    /*
     * ----------------------------------------------
     *
     * Constraints
     *
     * ----------------------------------------------
     */
    auto constraints = std::make_tuple(
            CollocationConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(),
            ControlRateConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(control_rate_lower, control_rate_upper),
            DynamicsConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(),
            InitialStateConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(initial_state),
            SmoothControlConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(),
            WaypointConstraints<Scalar, Index, n_x, n_u, n_c, n_w>(waypoints)
    );

    /* Create the fused constraint */
    FusedConstraint<decltype(constraints)> fused_constraint(constraints);

    /*
     * ----------------------------------------------
     *
     * IPOPT Problem definition
     *
     * ----------------------------------------------
     */
    /* Scalar of nonzeros in the Hessian of the Lagrangian (lower or upper triangualar part only).
     * Since we are using BFGS, we aren't computing the hessian, so we don't need this. */
    const Index hessian_nonzeros = 0;

    /* Indexing style for matrices... 0 denotes C-style counting from 0. */
    const Index index_style = 0;

    /* Create the IpoptProblem */
    IpoptProblem nlp = CreateIpoptProblem(n_vars,
                                          lower_bound.data(),
                                          upper_bound.data(),
                                          pd->fused_constraint.getNumberOfConstraints(),
                                          constraint_lower_bound.data(),
                                          constraint_upper_bound.data(),
                                          pd->fused_constraint.getNumberOfJacobianNonzeros(),
                                          hessian_nonzeros,
                                          index_style,
                                          &eval_f,
                                          &eval_g,
                                          &eval_grad_f,
                                          &eval_jac_g,
                                          &eval_h);

    const bool check_jacobians = false;
    if (check_jacobians) {

        Matrix<Scalar, n_vars, 1> xx;
        for (int i = 0; i < n_vars; ++i)
            xx(i) = i + 1;
        auto times = Get::times(xx.data());
        for (int i = 0; i < n_w; ++i) {
            times(i) = 1;
        }
        Bool new_x = true;
        using Mat = Matrix<Scalar, Dynamic, n_vars>;
        Mat full = full_jacobian(pd->fused_constraint, xx.data(), new_x, data);
        Mat fd = finite_difference(pd->fused_constraint, xx.data(), new_x, data);
        Mat check = check_jacobian(pd->fused_constraint, xx.data(), new_x, data);
        if (verbose) {
            bool ints = true;
            if (ints) {
                cout << "derivative coefficients" << endl
                     << endl
                     << pd->getter.rightDerivativeCoefficients() << endl
                     << "-------------------------------------" << endl;
                cout << "full_jacobian: " << endl
                     << endl
                     << full.cast<Index>() << endl
                     << "-------------------------------------" << endl;
                cout << "finite_difference: " << endl
                     << endl
                     << fd.cast<Index>() << endl
                     << "-------------------------------------" << endl;
                cout << "check_jacobian: " << endl
                     << endl
                     << check.cast<Index>() << endl
                     << "-------------------------------------" << endl;
            } else {
                IOFormat format(2, 0, " ", "\n", "", "", "", "");
                cout << "derivative coefficients" << endl
                     << endl
                     << pd->getter.rightDerivativeCoefficients() << endl
                     << "-------------------------------------" << endl;
                cout << "full_jacobian: " << endl
                     << endl
                     << full.format(format) << endl
                     << "-------------------------------------" << endl;
                cout << "finite_difference: " << endl
                     << endl
                     << fd.format(format) << endl
                     << "-------------------------------------" << endl;
                cout << "check_jacobian: " << endl
                     << endl
                     << check.format(format) << endl
                     << "-------------------------------------" << endl;
            }
            cout << "nonzero_rows" << endl
                 << endl
                 << pd->fused_constraint.getNonzeroJacobianRows() << endl
                 << endl;
            cout << "nonzero_cols" << endl
                 << endl
                 << pd->fused_constraint.getNonzeroJacobianCols() << endl
                 << endl;
        }
        cout << "max jacobian error: " << endl
             << endl
             << check.cwiseAbs().maxCoeff() << endl
             << "-------------------------------------"
             << endl;
        return 0;
    }

    /*
     * ----------------------------------------------
     *
     * IPOPT Solve
     *
     * ----------------------------------------------
     */
    /* Set some options for the solver */
    Strings str;
    AddIpoptNumOption(nlp, str("tol"), 1e-3);
    AddIpoptIntOption(nlp, str("max_iter"), 500);
    AddIpoptStrOption(nlp, str("mu_strategy"), str("adaptive"));
    AddIpoptStrOption(nlp, str("hessian_approximation"), str("limited-memory"));
    AddIpoptIntOption(nlp, str("print_level"), 0);
    // AddIpoptStrOption(nlp, str("warm_start_init_point"), str("yes"));

    /* objective value at the solution */
    Scalar obj = -1;

    /* Allocate space to store the bound multipliers at the solution.
     * If you are overflowing the stack, then you can malloc the memory,
     * but then you must free it after the FreeIpoptProblem call (and before returning). */
    /* constraint multipliers at the solution */
    Matrix<Scalar, Dynamic, 1> mult_g(pd->fused_constraint.getNumberOfConstraints());

    /* lower bound multipliers at the solution */
    Matrix<Scalar, n_vars, 1> mult_x_L;

    /* upper bound multipliers at the solution */
    Matrix<Scalar, n_vars, 1> mult_x_U;

    /* Set the callback method for intermediate user-control.  This is
     * not required, just gives you some intermediate control in case
     * you need it. */
    /* SetIntermediateCallback(nlp, intermediate_cb); */

    /* Solve the problem */
    Matrix<Scalar, n_vars, 1> solution = initial_guess;

    enum ApplicationReturnStatus status;
    long long elapsed = 0;
    const int iterations = 1;
    for (int iteration = 0; iteration < iterations; ++iteration) {
        solution = initial_guess;
        auto start = std::chrono::high_resolution_clock::now();
        status = IpoptSolve(nlp,
                            solution.data(),
                            NULL,
                            &obj,
                            mult_g.data(),
                            mult_x_L.data(),
                            mult_x_U.data(),
                            data);
        auto finish = std::chrono::high_resolution_clock::now();
        elapsed += std::chrono::duration_cast<std::chrono::nanoseconds>(finish - start).count();
    }
    cout << "Elapsed seconds for " << iterations << " calls: " << (elapsed / 1e9) << endl;

    /*
     * ----------------------------------------------
     *
     * Print the solution and other diagnostics
     *
     * ----------------------------------------------
     */
    /* Log the solution.
     * TODO: Ideally, these would be returned to the Java side. */
    cout << endl
         << "Status = " << status << endl
         << "Cost   = " << obj << endl
         << endl;

    if (verbose) {
        log_state<Scalar, Index, n_x, n_u, n_c, n_w>(solution.data());

        /* Show us the min and max value of all of the constraints at the solution */
        for (auto &constraint : equality_constraints) {
            Bool new_x = true;
            Matrix<Scalar, Dynamic, 1> g(constraint->getNumberOfConstraints());
            constraint->evaluate(solution.data(), new_x, g.data(), data);
            cout << "constraint min = " << g.minCoeff() << ", max = " << g.maxCoeff() << endl;
        }
    }

    /* Free allocated memory */
    FreeIpoptProblem(nlp);

    /* Beep when finished */
    cout << '\a';
    return obj;
}