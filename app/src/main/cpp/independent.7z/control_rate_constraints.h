#ifndef CONTROL_RATE_CONSTRAINTS_HEADER
#define CONTROL_RATE_CONSTRAINTS_HEADER

#include "variable_getter.h"
#include "Eigen/Dense"
#include "inequality_constraint.h"
#include "lagrange_derivatives.h"

/**
 * This set of constraints simply ensures that control rates lie within the specified bounds, that is,
 *
 * lower_bound <= u_dot <= upper_bound
 *
 * In general, an inequality bound is true if it is negative. So we reformulate the above to
 * the two bounds
 *
 * u_dot - upper_bound <= 0
 * lower_bound - u_dot <= 0
 *
 * @tparam Scalar: Only used to construct the lower and upper bounds.
 * @tparam n_constraints
*/
template<typename Scalar, typename Index, Index n_x, Index n_u, Index n_c, Index n_w>
struct ControlRateConstraints
        : InequalityConstraint<
                ControlRateConstraints<
                        Scalar, Index, n_x, n_u, n_c, n_w>, Scalar, Index, 2 * n_u * n_w * n_c> {

private:

    using Bound = Eigen::Matrix<Scalar, n_u, 1>;
    const Bound lower_bound;
    const Bound upper_bound;

    using Get = VariableGetter<Scalar, Index, n_x, n_u, n_c, n_w>;
    using Map = Eigen::Map<Eigen::Matrix<Scalar, n_u, n_c>>;

    using LD = LagrangeDerivatives<Scalar, Index, n_x, n_u, n_c, n_w, 1>;
    LD lagrange_derivatives;

public:

    ControlRateConstraints(const Bound &lower_bound,
                           const Bound &upper_bound)
            : lower_bound(lower_bound),
              upper_bound(upper_bound) {
    }

    ControlRateConstraints(const Bound &lower_bound,
                           const Bound &upper_bound,
                           const Eigen::Matrix<Scalar, n_c, 1> &collocation_points)
            : lower_bound(lower_bound),
              upper_bound(upper_bound),
              lagrange_derivatives(LD(collocation_points)) {
    }

    /** Evaluate the constraint at x and store the values in g.
     * Then return a pointer to g + n_constraints. */
    template<typename U, typename V>
    U *operator()(U *g, const V *x, LD &lagrange_derivatives) const {

        const Scalar *dx = lagrange_derivatives.template get<1>();
        for (Index i_w = 0; i_w < n_w; ++i_w) {

            Map upper(g);
            upper = Get::controlsAtWaypoint(dx, i_w).colwise() - upper_bound;
            g += n_u * n_c;

            Map lower(g);
            lower = (-Get::controlsAtWaypoint(dx, i_w)).colwise() + lower_bound;
            g += n_u * n_c;
        }
        return g;
    }

    /** If not explicitly provided, estimate the
     * derivatives using Lagrange interpolation polynomials,
     * then call the main method. */
    template<typename U, typename V>
    U *operator()(U *g, const V *x) {
        lagrange_derivatives.template generate<1>(x);
        return (*this)(g, x, lagrange_derivatives);
    }

    /** Evaluate the constraint at x and store the values in g.
     * Then return a pointer to g.data() + n_constraints. */
    template<typename U, typename V>
    auto operator()(U &g, const V &x) -> decltype(g.data()) {
        return (*this)(g.data(), x.data());
    }
};

#endif /* CONTROL_RATE_CONSTRAINTS_HEADER */