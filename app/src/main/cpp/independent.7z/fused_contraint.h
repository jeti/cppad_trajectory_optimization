#ifndef FUSED_CONSTRAINT_HEADER
#define FUSED_CONSTRAINT_HEADER

#include <tuple>
#include <array>
#include "lagrange_derivatives.h"

template<typename Tuple, typename Scalar, typename Index, Index n_x, Index n_u, Index n_c, Index n_w>
struct FusedConstraint {

public:

    /** Grab some types from the first element in the tuple. */
    using Scalar = typename std::tuple_element<0, Tuple>::type::Scalar;
    using Index = typename std::tuple_element<0, Tuple>::type::Index;

private:

    /* Define a type which holds an unsigned integer value */
    template<Index>
    struct Integer {
    };

    /*
     * ------------------------------------
     *
     * Number of Constraints
     *
     * ------------------------------------
     */
    static constexpr Index numberOfConstraints(Integer<0>) {
        return std::tuple_element<0, Tuple>::type::n_constraints;
    }

    template<Index i>
    static constexpr Index numberOfConstraints(Integer<i>) {
        return std::tuple_element<i, Tuple>::type::n_constraints + numberOfConstraints(Integer<i - 1>());
    }

public:

    /** The number of constraint classes that are fused together */
    static const Index n_constraint_classes = std::tuple_size<Tuple>::value;
    static_assert(n_constraint_classes > 0, "You must specify at least one constraint class");

    /** The size of the constraint vector */
    static const Index n_constraints = numberOfConstraints(Integer<n_constraint_classes - 1>());

private:

    /*
     * ------------------------------------
     *
     * Upper Bound
     *
     * ------------------------------------
     */
    static constexpr Scalar *fillUpperBound(Scalar *bound, Integer<n_constraint_classes - 1>) {
        return std::tuple_element<n_constraint_classes - 1, Tuple>::type::writeUpperBound(bound);
    }

    template<Index i>
    static constexpr Scalar *fillUpperBound(Scalar *bound, Integer<i>) {
        return fillUpperBound(std::tuple_element<i, Tuple>::type::writeUpperBound(bound), Integer<i + 1>());
    }

    static std::array<Scalar, n_constraints> createUpperBound() {
        std::array<Scalar, n_constraints> bound;
        fillUpperBound(bound.data(), Integer<0>());
        return bound;
    }

    /*
     * ------------------------------------
     *
     * Lower Bound
     *
     * ------------------------------------
     */
    static constexpr Scalar *fillLowerBound(Scalar *bound, Integer<n_constraint_classes - 1>) {
        return std::tuple_element<n_constraint_classes - 1, Tuple>::type::writeLowerBound(bound);
    }

    template<Index i>
    static constexpr Scalar *fillLowerBound(Scalar *bound, Integer<i>) {
        return fillLowerBound(std::tuple_element<i, Tuple>::type::writeLowerBound(bound), Integer<i + 1>());
    }

    static std::array<Scalar, n_constraints> createLowerBound() {
        std::array<Scalar, n_constraints> bound;
        fillLowerBound(bound.data(), Integer<0>());
        return bound;
    }

    using LD = LagrangeDerivatives<Scalar, Index, n_x, n_u, n_c, n_w, 1>;
    LD lagrange_derivatives;

public:

    const std::array<Scalar, n_constraints> lower_bound = createLowerBound();

    const std::array<Scalar, n_constraints> upper_bound = createUpperBound();

    /** A tuple of the constraint classes that we fuse together.
     * Note that we are referencing the passed-in constraints to avoid making copies */
    Tuple constraints;

    /* Constructors */
    FusedConstraint(const Tuple &constraints)
            : constraints(constraints) {
    }

    FusedConstraint(const Tuple &constraints,
                    const Eigen::Matrix<Scalar, n_c, 1> &collocation_points)
            : constraints(constraints),
              lagrange_derivatives(LD(collocation_points)) {
    }

    /** Evaluate the constraint at x and store the values in g.
     * Then return a pointer to g + n_constraints. */
    template<typename U, typename V>
    U *operator()(U *g, const V *x) {

        // TODO Evaluate the lagrange derivatives at the max derivative value
        return evaluateConstraintsTuple(g, x, Integer<0>());
    }

    /** Evaluate the constraint at x and store the values in g.
     * Then return a pointer to g.data() + n_constraints. */
    template<typename U, typename V>
    auto operator()(U &g, const V &x) -> decltype(g.data()) {
        return (*this)(g.data(), x.data());
    }

private:

    /*
     * ------------------------------------
     *
     * Evaluate
     *
     * ------------------------------------
     */
    /** Evaluate the constraint at x and store the values in g.
     * Then return a pointer to g + n_constraints. */
    template<typename U, typename V>
    U *evaluateConstraintsTuple(U *g, const V *x, Integer<n_constraint_classes - 1>) {
        return std::get<n_constraint_classes - 1>(constraints)(g, x);
    }

    /** Evaluate the constraint at x and store the values in g.
     * Then return a pointer to g + n_constraints. */
    template<typename U, typename V, Index i, typename NeedsDerivatives>
    U *evaluateConstraintsTuple(U *g, const V *x, Integer<i>, NeedsDerivatives::yes) {
        return evaluateConstraintsTuple(std::get<i>(constraints)(g, x), x, Integer<i + 1>());
    }
};

#endif /* FUSED_CONSTRAINT_HEADER */